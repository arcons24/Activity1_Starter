<?php
// logout.php – ACTIVITY 1
// Goal: FULLY destroy the session so the old session ID becomes useless.
declare(strict_types=1);
require __DIR__ . '/includes/init.php';

$_SESSION = [];

if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
}

session_destroy();

header('Location: ' . BASE_URL . '/login.php');
exit;

